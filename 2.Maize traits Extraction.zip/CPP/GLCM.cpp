#define DLL_API extern "C" _declspec(dllexport)
#include<stdio.h>
#include <math.h>
#include "stdlib.h"


DLL_API void createGLCM( unsigned char *G,
						 unsigned char *Grad,
						 unsigned char *mask,
						 int row,
						 int col,
						 int level,
						 int N,
						 float *T,
						 float *GLCM);
DLL_API void createGLCM(unsigned char *G,
						unsigned char *Grad,
						unsigned char *mask,
						int row,
						int col,
						int level,
						int N,
						float *T,
						float *GLCM)
{
	if ( N <= 0 )
		return;
	int size = level * level;
	//float *GLCM = new float[size];
	int i, j, index, index1;

	for ( i = 0; i < size; i++ )
		GLCM[i] = .0f;

	for ( i = 0; i < row; i++ )
		for ( j = 0; j < col; j++ )
		{
			index = i * col + j;
			if ( mask[index] !=0 )
			{
				//if ( G[index] * Grad[index] != 0 )
				{
					index1 = (G[index]-1) *level+Grad[index]-1;
					//if ( index1 < size )
					GLCM[index1]++;// = GLCM[index1] + 1;					
				}
			}
		}

		for ( i = 0; i < size; i++ )
			GLCM[i] /= N;

		float GSum, GradSum;
		for ( i = 0; i < level; i++ )
		{
			GradSum = GSum = 0.0f;
			for ( j = 0; j < level; j++ )
			{
				index = i * level + j;
				index1 = j * level + i;				
				T[1] += GLCM[index] / (j+1) / (j+1); //С�ݶ�����
				T[2] += GLCM[index] * (j+1) * (j+1);   //���ݶ�����
				T[3] += GLCM[index] * GLCM[index]; //����
				GSum += GLCM[index];
				GradSum += GLCM[index1];
				if ( GLCM[index]!= 0 )
					T[10] -= GLCM[index] * log(GLCM[index]); //�����
				T[11] += (i-j) * (i-j) * GLCM[index]; //��־�
				T[12] += GLCM[index] / ( 1+(i-j) * (i-j) ); //���־�
			}
			T[4] += GSum * GSum;  //�Ҷȷֲ���������
			T[5] += GradSum * GradSum;   //�ݶȷֲ���������
			T[6] += GSum * (i+1); //�ҶȾ�ֵ
			T[7] += GradSum * (i+1);   //�ݶȾ�ֵ
			if ( GSum!=0 )
				T[8] -= GSum * log(GSum); //�Ҷ���
			if ( GradSum!=0 )
				T[9] -= GradSum * log(GradSum); //�ݶ���

		}
			for ( i = 0; i < level; i++ )
			{
				GradSum = GSum = 0.0f;
				for ( j = 0; j < level; j++ )
				{
					index = i * level + j;
					index1 = j * level + i;
					GSum += GLCM[index];
					GradSum += GLCM[index1];
					T[0] += (i-T[6]) * (j-T[7]) * GLCM[index]; //�����
				}
				T[13] += (i-T[6]) * (i-T[6]) * GSum;
				T[14] += (i-T[7]) * (i-T[7]) * GradSum;
			}
			T[13] = sqrt(T[13]);   //�Ҷȱ�׼��
			T[14] = sqrt(T[14]);   //�ݶȱ�׼��
			T[0] = T[0] / T[6] / T[7]; //�����

			//delete []GLCM;

}